<?php
/**
 * 左侧栏:可配置模块(suxing 风格)。
 * 由 home.php / archive.php / search.php 经 get_sidebar( 'left' ) 引入。
 * 模块(固定顺序):作者卡 → 自定义文本 → 最新文章 → 热门文章。
 * 各模块由后台「外观 → 自定义 → 左侧栏模块」开关控制;全关时不输出 aside。
 * ≤1180px 时由 layout.css 隐藏(.sidebar-left { display:none })。
 *
 * @package OneDong
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$any_left =
	get_theme_mod( 'onedong_left_author', 1 ) ||
	get_theme_mod( 'onedong_left_image', 0 ) ||
	get_theme_mod( 'onedong_left_text', 0 ) ||
	get_theme_mod( 'onedong_left_recent', 0 ) ||
	get_theme_mod( 'onedong_left_popular', 0 );

if ( ! $any_left ) {
	return; // 全关:不输出空侧栏
}
?>
<aside id="profile" class="sidebar-left" aria-label="<?php esc_attr_e( '作者资料与侧栏模块', 'onedong' ); ?>">

	<?php if ( get_theme_mod( 'onedong_left_author', 1 ) ) : ?>
		<section class="widget widget-profile">
			<div class="widget-profile__avatar-wrap">
				<?php
				$avatar_source = get_theme_mod( 'onedong_avatar_source', 'logo' );
				if ( 'logo' === $avatar_source && has_custom_logo() ) :
					$logo_id = get_theme_mod( 'custom_logo' );
					echo wp_get_attachment_image(
						$logo_id,
						array( 96, 96 ),
						false,
						array(
							'class' => 'widget-profile__avatar',
							'alt'   => esc_attr( get_bloginfo( 'name' ) ),
						)
					);
				elseif ( 'gravatar' === $avatar_source ) :
					echo get_avatar(
						get_bloginfo( 'admin_email' ),
						96,
						'retro',
						esc_attr( get_bloginfo( 'name' ) ),
						array( 'class' => 'widget-profile__avatar' )
					);
				elseif ( 'custom' === $avatar_source ) :
					$custom_avatar = get_theme_mod( 'onedong_avatar_custom', '' );
					if ( $custom_avatar ) :
						?>
						<img class="widget-profile__avatar" src="<?php echo esc_url( $custom_avatar ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
						<?php
					endif;
				endif;
				?>
				<span class="widget-profile__verified" aria-label="<?php esc_attr_e( '认证作者', 'onedong' ); ?>">
					<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
						<circle cx="12" cy="12" r="11" fill="#FFB300"/>
						<path d="M7 12.5l3.2 3.2L17 9" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
				</span>
			</div>
			<?php
			$author_user = get_user_by( 'email', get_bloginfo( 'admin_email' ) );
			$author_name = $author_user ? $author_user->display_name : get_bloginfo( 'name' );
			?>
			<h2 class="widget-profile__name">
				<?php echo $author_user ? '<a href="' . esc_url( get_author_posts_url( $author_user->ID ) ) . '">' . esc_html( $author_name ) . '</a>' : esc_html( $author_name ); ?>
				<span class="online-dot" aria-label="<?php esc_attr_e( '在线', 'onedong' ); ?>"></span>
			</h2>
			<?php if ( get_bloginfo( 'description' ) ) : ?>
				<p class="widget-profile__desc"><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p>
			<?php endif; ?>
		</section>

		<?php if ( get_theme_mod( 'onedong_show_author_stats', 1 ) ) : ?>
			<?php
			$post_count    = (int) wp_count_posts()->publish;
			$comment_count = (int) wp_count_comments()->approved;
			?>
			<section class="widget widget-profile-stats">
				<div class="widget-profile__stats">
					<span class="widget-profile__stat">
						<strong><?php onedong_icon( 'document' ); ?><?php echo esc_html( number_format_i18n( $post_count ) ); ?></strong>
						<small><?php esc_html_e( '文章', 'onedong' ); ?></small>
					</span>
					<span class="widget-profile__stat">
						<strong><?php onedong_icon( 'chat' ); ?><?php echo esc_html( number_format_i18n( $comment_count ) ); ?></strong>
						<small><?php esc_html_e( '评论', 'onedong' ); ?></small>
					</span>
				</div>
			</section>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ( get_theme_mod( 'onedong_left_image', 0 ) ) { onedong_widget_image( 'left' ); } ?>
	<?php if ( get_theme_mod( 'onedong_left_text', 0 ) ) { onedong_widget_text( 'left' ); } ?>
	<?php if ( get_theme_mod( 'onedong_left_recent', 0 ) ) { onedong_widget_recent_posts(); } ?>
	<?php if ( get_theme_mod( 'onedong_left_popular', 0 ) ) { onedong_widget_popular_posts(); } ?>

</aside>
